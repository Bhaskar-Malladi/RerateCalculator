import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class reRateService {

  constructor() {


  }

}


export class ReRateMasterService {
  country: string;
  note: string;
  passport: boolean;
  wificall: boolean;
  daypass: boolean;
  domesticeligibility: boolean;
  planname: string;
  cost: number;
  ppurates: number;
  adjustmentrate: number;
  roamingcharges: number;
}


export const ReRateMasaters: ReRateMasterService[] =

  [
  {
    country: "Angola",
    note: "Test Angola note",
    passport: true,
    wificall: false,
    daypass: false,
    domesticeligibility: false,
    planname: "",
    cost: 220,
      ppurates: 9097,
      adjustmentrate: 1000,
      roamingcharges : 1000
  },
  {
    country: "Algeria",
    note: "this is another test note",
    passport: true,
    wificall: true,
    daypass: true,
    domesticeligibility: true,
    planname: "",
    cost: 220,
    ppurates: 9097,
    adjustmentrate: 1000,
    roamingcharges: 1000
  }
  ]


