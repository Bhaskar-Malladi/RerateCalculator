import { Component,OnInit } from '@angular/core';
import { ReRateMasaters } from '../global/global-service'
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'reRate-calculator';
  rerateData = ReRateMasaters;
  private daypass: boolean = false;
  private passport: boolean = false;
  private wificall: boolean = false;
  private pprrates: boolean = false;
  private domesticeligibility: boolean = false;
  private cost: number;
  private note: string;
  private isShowBestPlan: boolean = true;
  private isShowAvailableplans: boolean = false;
  private isShowoverridePlans: boolean = false;
  private isShownegotiatePlans: boolean = false;
  private adjustmentrate: number;
  private roamingcharges: number;
  constructor() {

  }
  ngOnInit() {
   
  }
  changeCountry(event) {
    let self = this;
    var selectedCountry = event.currentTarget.value;
   // print(filtered);
    $.map(this.rerateData, function (val, i) {
      if (val.country == selectedCountry) {
        self.passport = val.passport;
        self.wificall = val.wificall;
        self.pprrates = val.pprrates;
        self.daypass = val.daypass;
        self.domesticeligibility = val.domesticeligibility;
        self.cost = val.cost;
        self.note = val.note;
        self.adjustmentrate = val.adjustmentrate;
        self.roamingcharges = val.roamingcharges;
      }
    });
  }
  reRatePlanChange(event) {
    debugger;
    var selectedPlan = $(event.currentTarget).attr('data-planname');
    switch (selectedPlan){
      case 'bestplan':
        this.isShowBestPlan = true;
        this.isShowAvailableplans = false;
        this.isShowoverridePlans = false;
        this.isShownegotiatePlans = false;
        break;
      case 'availableplans':
        this.isShowBestPlan = false;
        this.isShowAvailableplans = true;
        this.isShowoverridePlans = false;
        this.isShownegotiatePlans = false;
        break;
      case 'overrideplan':
        this.isShowBestPlan = false;
        this.isShowAvailableplans = false;
        this.isShowoverridePlans = true;
        this.isShownegotiatePlans = false;
        break;
      case 'negotiateplan':
        this.isShowBestPlan = false;
        this.isShowAvailableplans = false;
        this.isShowoverridePlans = false;
        this.isShownegotiatePlans = true;
        break;
    }


  }
}

